//import {CryptoJS} from './cryptos'
function b64_to_utf8( str ) {return decodeURIComponent(escape(window.atob( str )));}
document.getElementsByName('password')[0].style.display="none";
document.getElementsByName('password')[0].value = b64_to_utf8(localStorage.getItem("prop"));
document.querySelector("button[jsname='LgbsSe']").click();


