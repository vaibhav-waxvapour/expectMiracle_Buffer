const adminSecret="r%w@aaq!90^";

document.oncontextmenu=RightMouseDown;
document.onmousedown = mouseDown; 
function mouseDown(e) {if (e.which==3) {}}function RightMouseDown() { return false;}

function utf8_to_b64( str ) {
    return window.btoa(unescape(encodeURIComponent( str )));
  }

function getUrl()
{
    chrome.tabs.query({active: true, lastFocusedWindow: true}, tabs => {
        let url = tabs[0].url;
        chrome.tabs.query({currentWindow: true, active: true}, function(tabs){
            chrome.tabs.reload(tabs[0].url);
        });
    });
}

function getadmin()
{
document.getElementById('basic').style.display='none';
document.getElementById('conf').style.display='block';
}

function updater(){
    if(document.getElementById('secret').value == adminSecret){
        
        chrome.storage.local.set({prop : utf8_to_b64(document.getElementById('prop').value)}, function(){
            chrome.storage.local.get('prop',(e)=>{});
        });
            
    }
    else
        alert("Wrong Secret");
}

document.addEventListener('DOMContentLoaded', function () {
    document.getElementById('login').addEventListener('click', getUrl);
});

document.addEventListener('DOMContentLoaded', function () {
    document.getElementById('admin').addEventListener('click', getadmin);
});

document.addEventListener('DOMContentLoaded', function () {
    document.getElementById('aSubmit').addEventListener('click', updater);
            
});